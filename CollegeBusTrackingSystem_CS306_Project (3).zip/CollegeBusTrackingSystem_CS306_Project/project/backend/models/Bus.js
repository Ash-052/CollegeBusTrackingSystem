import mongoose from 'mongoose';

const BusSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Bus name is required'],
    trim: true
  },
  busNumber: {
    type: String,
    required: [true, 'Bus number is required'],
    unique: true,
    trim: true
  },
  type: {
    type: String,
    enum: ['student', 'faculty', 'mixed'],
    default: 'student'
  },
  capacity: {
    type: Number,
    required: [true, 'Bus capacity is required'],
    min: [1, 'Capacity must be at least 1']
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'maintenance', 'out-of-service'],
    default: 'inactive'
  },
  driver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  route: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Route'
  },
  location: {
    lat: {
      type: Number,
      default: 16.4845 // SRM University Amaravati default latitude
    },
    lng: {
      type: Number,
      default: 80.5115 // SRM University Amaravati default longitude
    },
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  },
  currentPassengers: {
    type: Number,
    default: 0,
    min: 0
  },
  nextStop: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'BusStop'
  },
  estimatedArrival: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field before saving
BusSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Virtual for available seats
BusSchema.virtual('availableSeats').get(function() {
  return Math.max(0, this.capacity - this.currentPassengers);
});

// Virtual for total seats
BusSchema.virtual('totalSeats').get(function() {
  return this.capacity;
});

// Ensure virtuals are included in JSON output
BusSchema.set('toJSON', { virtuals: true });
BusSchema.set('toObject', { virtuals: true });

const Bus = mongoose.model('Bus', BusSchema);

export default Bus;