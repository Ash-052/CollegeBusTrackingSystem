import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address']
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters']
  },
  role: {
    type: String,
    enum: ['student', 'faculty', 'driver', 'admin'],
    default: 'student'
  },
  profilePicture: {
    type: String,
    default: ''
  },
  favoriteRoutes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Route'
  }],
  notificationPreferences: {
    email: {
      enabled: {
        type: Boolean,
        default: true
      },
      types: {
        routeChanges: {
          type: Boolean,
          default: true
        },
        delayAlerts: {
          type: Boolean,
          default: true
        },
        announcements: {
          type: Boolean,
          default: true
        }
      }
    },
    push: {
      enabled: {
        type: Boolean,
        default: true
      },
      types: {
        routeChanges: {
          type: Boolean,
          default: true
        },
        delayAlerts: {
          type: Boolean,
          default: true
        },
        announcements: {
          type: Boolean,
          default: true
        }
      }
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastLogin: {
    type: Date,
    default: Date.now
  }
});

// Hash password before saving
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
UserSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw error;
  }
};

const User = mongoose.model('User', UserSchema);

export default User;