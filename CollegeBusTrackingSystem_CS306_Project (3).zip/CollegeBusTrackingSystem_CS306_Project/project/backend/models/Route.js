import mongoose from 'mongoose';

const routeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    enum: ['Chilles', 'Gorantla', 'Vidyanagar', 'Pattabhi Puram'],
    unique: true
  },
  description: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['student', 'faculty', 'mixed'],
    default: 'student'
  },
  color: {
    type: String,
    default: '#3B82F6' // Default blue color
  },
  isActive: {
    type: Boolean,
    default: true
  },
  stops: [{
    name: {
      type: String,
      required: true
    },
    time: {
      type: String,
      required: true
    }
  }],
  schedule: [{
    day: {
      type: String,
      required: true,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    departureTime: {
      type: String,
      required: true
    },
    arrivalTime: {
      type: String,
      required: true
    }
  }],
}, {
  timestamps: true
});

// Virtual for getting all buses on this route
routeSchema.virtual('buses', {
  ref: 'Bus',
  localField: '_id',
  foreignField: 'route'
});

// Ensure virtuals are included in JSON output
routeSchema.set('toJSON', { virtuals: true });
routeSchema.set('toObject', { virtuals: true });

const Route = mongoose.model('Route', routeSchema);

export default Route;