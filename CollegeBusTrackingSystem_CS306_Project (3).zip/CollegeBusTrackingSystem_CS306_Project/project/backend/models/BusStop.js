import mongoose from 'mongoose';

const BusStopSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Bus stop name is required'],
    trim: true
  },
  code: {
    type: String,
    required: [true, 'Bus stop code is required'],
    unique: true,
    trim: true
  },
  location: {
    lat: {
      type: Number,
      required: [true, 'Latitude is required']
    },
    lng: {
      type: Number,
      required: [true, 'Longitude is required']
    }
  },
  address: {
    type: String,
    trim: true
  },
  facilities: {
    shelter: {
      type: Boolean,
      default: false
    },
    seating: {
      type: Boolean,
      default: false
    },
    lighting: {
      type: Boolean,
      default: false
    },
    accessibilityFeatures: {
      type: Boolean,
      default: false
    }
  },
  active: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field before saving
BusStopSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Virtual for all routes that include this stop
BusStopSchema.virtual('routes', {
  ref: 'Route',
  localField: '_id',
  foreignField: 'stops.stop'
});

// Ensure virtuals are included in JSON output
BusStopSchema.set('toJSON', { virtuals: true });
BusStopSchema.set('toObject', { virtuals: true });

const BusStop = mongoose.model('BusStop', BusStopSchema);

export default BusStop;